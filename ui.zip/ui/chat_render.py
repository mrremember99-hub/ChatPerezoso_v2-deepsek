"""Renderizado del chat: todo lo que decide cómo se ve un mensaje dentro del
QTextEdit. No conoce Ollama, MCP ni hilos — solo recibe texto y lo pinta.
"""
from __future__ import annotations

import html

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import QTextEdit

from . import design
from .widgets import USER_MESSAGE_PROPERTY


class ChatRenderer:
    """Dibuja mensajes de usuario, respuestas en streaming y eventos de
    herramienta sobre un QTextEdit ya construido (``chat``), y lleva el
    estado necesario para reconstruir el segmento de respuesta en curso.
    """

    def __init__(self, chat: QTextEdit):
        self.chat = chat
        self.response_text = ""
        self.response_start: int | None = None
        self.response_segment = ""

    def reset(self) -> None:
        """Prepara el estado para una respuesta nueva (se llama al enviar)."""
        self.response_text = ""
        self.response_start = None
        self.response_segment = ""

    def reset_response_segment(self) -> None:
        """Corta el segmento actual sin tocar response_text acumulado (se
        llama cuando llega un evento de herramienta en medio de la respuesta)."""
        self.response_start = None
        self.response_segment = ""

    # -- mensajes de usuario -------------------------------------------------

    def insert_user_message(self, text: str) -> None:
        cursor = self.chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        if cursor.position() > 0 and not cursor.atBlockStart():
            cursor.insertBlock()
        safe_text = html.escape(text).replace("\n", "<br>")
        cursor.insertHtml(
            f'<div style="margin:{design.USER_MESSAGE_MARGIN}; '
            f'padding:{design.USER_MESSAGE_PADDING}; '
            f'color:{design.USER_MESSAGE_TEXT_COLOR}; '
            f'font-size:{design.USER_MESSAGE_FONT_SIZE_PX}px;">'
            f'{safe_text}'
            '</div>'
        )
        block = cursor.block()
        block_format = block.blockFormat()
        block_format.setProperty(USER_MESSAGE_PROPERTY, True)
        cursor.setBlockFormat(block_format)
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertBlock()
        self.chat.setTextCursor(cursor)
        self.chat.ensureCursorVisible()

    # -- respuesta en streaming ----------------------------------------------

    @staticmethod
    def display_response_text(text: str) -> str:
        """Normaliza saltos reales y escapados sin perder párrafos."""
        return (
            text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .replace("\\r\\n", "\n")
            .replace("\\n", "\n")
        )

    @staticmethod
    def clean_response_text(text: str) -> str:
        """Elimina un encabezado PEREZOSO que algunos modelos añaden a la respuesta."""
        stripped = text.lstrip()
        prefixes = ("**PEREZOSO**", "PEREZOSO:", "PEREZOSO")
        for prefix in prefixes:
            if stripped.startswith(prefix):
                stripped = stripped[len(prefix):].lstrip(" \n:")
                break
        return stripped

    def on_text(self, text: str) -> None:
        text = self.display_response_text(text)
        if not text:
            return
        self.response_text += text
        self.response_segment += text
        self.response_segment = self.clean_response_text(self.response_segment)

        cursor = self.chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        if self.response_start is None:
            if cursor.position() > 0 and not cursor.atBlockStart():
                cursor.insertBlock()
            self.response_start = cursor.position()

        # Durante cada ronda reconstruimos solo el segmento actual. Así los
        # saltos escapados que llegan partidos entre varios chunks se recomponen
        # antes de mostrarse y podemos aplicar un margen real a cada párrafo.
        replace_cursor = QTextCursor(self.chat.document())
        replace_cursor.setPosition(self.response_start)
        replace_cursor.movePosition(
            QTextCursor.MoveOperation.End,
            QTextCursor.MoveMode.KeepAnchor,
        )
        replace_cursor.removeSelectedText()
        replace_cursor.setPosition(self.response_start)
        fmt = QTextCharFormat()
        fmt.setFontWeight(QFont.Weight.Normal)
        fmt.setForeground(Qt.GlobalColor.lightGray)
        replace_cursor.setCharFormat(fmt)

        paragraphs = self.response_segment.split("\n")
        right_margin = max(
            0.0, self.chat.viewport().width() * design.RESPONSE_RIGHT_MARGIN_RATIO
        )
        for index, paragraph in enumerate(paragraphs):
            if index:
                replace_cursor.insertBlock()
            replace_cursor.insertText(paragraph)
            block = replace_cursor.blockFormat()
            block.setTopMargin(
                design.RESPONSE_FIRST_PARAGRAPH_TOP_MARGIN
                if index == 0
                else design.RESPONSE_PARAGRAPH_TOP_MARGIN
            )
            block.setBottomMargin(design.RESPONSE_PARAGRAPH_BOTTOM_MARGIN)
            block.setRightMargin(right_margin)
            replace_cursor.setBlockFormat(block)

        self.chat.setTextCursor(replace_cursor)
        self.chat.ensureCursorVisible()

    # -- eventos de herramienta ------------------------------------------------

    def insert_tool_event(self, text: str, color: str) -> None:
        self.reset_response_segment()
        cursor = self.chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        if cursor.position() > 0 and not cursor.atBlockStart():
            cursor.insertBlock()
        cursor.insertHtml(
            f'<div style="margin:8px 0 4px 0; color:{color}; '
            f'font-size:{design.TOOL_EVENT_FONT_SIZE_PT}pt;">'
            f'{html.escape(text)}</div>'
        )
        cursor.insertBlock()
        self.chat.setTextCursor(cursor)
        self.chat.ensureCursorVisible()

    def insert_tool_result(self, text: str) -> None:
        cursor = self.chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        safe_text = html.escape(text).replace("\n", "<br>")
        cursor.insertHtml(
            '<div style="margin:0 0 10px 20px; padding:8px 10px; '
            f'background:{design.TOOL_RESULT_BG_COLOR}; '
            f'border:1px solid {design.TOOL_RESULT_BORDER_COLOR}; '
            f'border-radius:{design.TOOL_RESULT_BORDER_RADIUS_PX}px; '
            f'color:{design.TOOL_RESULT_TEXT_COLOR}; font-family:monospace; '
            f'font-size:{design.TOOL_RESULT_FONT_SIZE_PT}pt;">'
            f'{safe_text}'
            '</div>'
        )
        cursor.insertBlock()
        self.chat.setTextCursor(cursor)
        self.chat.ensureCursorVisible()

    # -- errores ---------------------------------------------------------------

    def insert_error(self, message: str) -> None:
        cursor = self.chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = QTextCharFormat()
        fmt.setForeground(Qt.GlobalColor.red)
        cursor.setCharFormat(fmt)
        cursor.insertText(f"\n\nError: {message}\n")
        self.chat.setTextCursor(cursor)
