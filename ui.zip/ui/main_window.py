from __future__ import annotations

import shlex
import sys
from pathlib import Path
from typing import Any

from PySide6.QtCore import QElapsedTimer, QThread, QTimer, Qt, Slot
from PySide6.QtWidgets import (
    QFileDialog,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from core.config import AppConfig
from core.ollama import OllamaClient
from core.tools import ToolRegistry
from core.workspace import Workspace, WorkspaceError
from plugins.mcp import MCPClient, MCPError, MCPServerConfig, MCPToolBridge

from . import design
from .chat_render import ChatRenderer
from .widgets import ChatInput, ChatView
from .workers import ChatWorker, MCPWorker, ModelWorker


class MainWindow(QMainWindow):
    """Interfaz de ChatPerezoso v2 con la estética del proyecto anterior."""

    def __init__(self) -> None:
        super().__init__()
        self.config = AppConfig.load()
        self.ollama = OllamaClient(self.config.ollama_host)
        self.workspace = Workspace(self.config.workspace_path())
        self.tools = ToolRegistry(self.workspace)
        self.mcp = MCPToolBridge(self.tools)
        self.messages: list[dict] = []
        self._thread: QThread | None = None
        self._worker: ChatWorker | None = None
        self._model_thread: QThread | None = None
        self._model_worker: ModelWorker | None = None
        self._mcp_threads: dict[str, QThread] = {}
        self._mcp_workers: dict[str, MCPWorker] = {}
        self._streaming = False
        self._elapsed = QElapsedTimer()
        self._thinking_step = 0
        self._build_ui()
        self.chat_render = ChatRenderer(self.chat)
        self._thinking_timer = QTimer(self)
        self._thinking_timer.setInterval(design.THINKING_TIMER_INTERVAL_MS)
        self._thinking_timer.timeout.connect(self._animate_thinking)
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(design.ELAPSED_TIMER_INTERVAL_MS)
        self._elapsed_timer.timeout.connect(self._update_elapsed)
        self._load_models()

    def _build_ui(self) -> None:
        self.setWindowTitle("PEREZOSO")
        self.resize(self.config.width, self.config.height)

        central = QSplitter()
        central.setChildrenCollapsible(False)
        self.setCentralWidget(central)

        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(design.SIDEBAR_WIDTH_PX)
        s_layout = QVBoxLayout(sidebar)
        s_layout.setContentsMargins(14, 14, 14, 14)
        s_layout.setSpacing(7)

        title = QLabel("PEREZOSO")
        title.setObjectName("AppTitle")
        s_layout.addWidget(title)
        model_title = QLabel("MODELO")
        model_title.setObjectName("SectionTitle")
        s_layout.addWidget(model_title)
        self.model_combo = QComboBox()
        s_layout.addWidget(self.model_combo)

        mcp_title = QLabel("SERVIDORES MCP")
        mcp_title.setObjectName("SectionTitle")
        s_layout.addWidget(mcp_title)

        self.mcp_add_button = QPushButton("Añadir servidor MCP")
        self.mcp_add_button.setObjectName("SecondaryButton")
        self.mcp_add_button.clicked.connect(self._toggle_mcp)
        s_layout.addWidget(self.mcp_add_button)

        self.mcp_servers_widget = QWidget()
        self.mcp_servers_layout = QVBoxLayout(self.mcp_servers_widget)
        self.mcp_servers_layout.setContentsMargins(0, 0, 0, 0)
        self.mcp_servers_layout.setSpacing(4)
        s_layout.addWidget(self.mcp_servers_widget)

        refresh = QPushButton("Actualizar modelos")
        refresh.setObjectName("SecondaryButton")
        refresh.clicked.connect(self._load_models)
        s_layout.addWidget(refresh)

        s_layout.addSpacing(12)
        workspace_title = QLabel("CARPETA DE TRABAJO")
        workspace_title.setObjectName("SectionTitle")
        s_layout.addWidget(workspace_title)
        self.workspace_label = QLabel(self._workspace_display_name())
        self.workspace_label.setObjectName("FolderLabel")
        self.workspace_label.setWordWrap(True)
        self.workspace_label.setAutoFillBackground(False)
        self.workspace_label.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        s_layout.addWidget(self.workspace_label)

        choose = QPushButton("Cambiar carpeta")
        choose.setObjectName("SecondaryButton")
        choose.clicked.connect(self._choose_workspace)
        s_layout.addWidget(choose)
        s_layout.addStretch(1)

        clear = QPushButton("Nueva conversación")
        clear.clicked.connect(self._clear_chat)
        s_layout.addWidget(clear)
        central.addWidget(sidebar)

        chat_area = QWidget()
        chat_area.setObjectName("ChatArea")
        c_layout = QVBoxLayout(chat_area)
        c_layout.setContentsMargins(28, 22, 28, 18)
        c_layout.setSpacing(12)

        self.chat = ChatView()
        self.chat.setObjectName("ChatView")
        self.chat.setReadOnly(True)
        self.chat.document().setUndoRedoEnabled(False)
        self.chat.document().setMaximumBlockCount(5000)
        c_layout.addWidget(self.chat, 1)

        self.thinking_label = QLabel("•••")
        self.thinking_label.setObjectName("ThinkingLabel")
        self.thinking_label.setAlignment(Qt.AlignLeft)
        self.thinking_label.hide()
        c_layout.addWidget(self.thinking_label)

        input_row = QHBoxLayout()
        input_row.setSpacing(8)
        self.input = ChatInput()
        self.input.setObjectName("ChatInput")
        self.input.setFixedHeight(design.CHAT_INPUT_HEIGHT_PX)
        self.input.setPlaceholderText("Escribe un mensaje. Enter para enviar, Shift+Enter para nueva línea.")
        self.input.submitted.connect(self._send)
        input_row.addWidget(self.input, 1)

        self.send = QPushButton("Enviar")
        self.send.setFixedWidth(68)
        self.send.clicked.connect(self._send)
        input_row.addWidget(self.send)
        c_layout.addLayout(input_row)

        central.addWidget(chat_area)
        central.setStretchFactor(0, 0)
        central.setStretchFactor(1, 1)

        self.setStatusBar(self.statusBar())
        self.status = QLabel("Listo")
        self.status.setObjectName("StatusText")
        self.statusBar().addWidget(self.status, 1)
        self.elapsed_label = QLabel("● 0.0 s")
        self.elapsed_label.setObjectName("ElapsedIndicator")
        self.statusBar().addPermanentWidget(self.elapsed_label)

    def _workspace_display_name(self) -> str:
        """Muestra solo el nombre de la carpeta de trabajo, no su ruta completa."""
        return self.workspace.root.name or str(self.workspace.root)

    def _load_models(self) -> None:
        if self._streaming or self._model_thread is not None:
            return
        self.status.setText("Consultando Ollama…")
        self._model_thread = QThread()
        self._model_worker = ModelWorker(self.ollama)
        self._model_worker.moveToThread(self._model_thread)
        self._model_thread.started.connect(self._model_worker.run)
        self._model_worker.finished.connect(self._models_loaded)
        self._model_worker.error.connect(self._models_error)
        self._model_worker.finished.connect(self._model_thread.quit)
        self._model_worker.error.connect(self._model_thread.quit)
        self._model_thread.finished.connect(self._cleanup_model_thread)
        self._model_thread.start()

    def _models_loaded(self, models: list[str]) -> None:
        self.model_combo.clear()
        self.model_combo.addItems(models)
        if self.config.model in models:
            self.model_combo.setCurrentText(self.config.model)
        self.status.setText(f"{len(models)} modelo(s) disponibles")

    def _models_error(self, message: str) -> None:
        self.status.setText("Ollama no disponible")
        QMessageBox.warning(self, "Ollama", message)

    def _cleanup_model_thread(self) -> None:
        if self._model_worker is not None:
            self._model_worker.deleteLater()
        if self._model_thread is not None:
            self._model_thread.deleteLater()
        self._model_worker = None
        self._model_thread = None

    def _choose_workspace(self) -> None:
        selected = QFileDialog.getExistingDirectory(
            self, "Seleccionar workspace", str(self.workspace.root)
        )
        if not selected:
            return
        try:
            # El workspace forma parte de los argumentos del filesystem MCP.
            # Cerramos tanto conexiones activas como conexiones aún pendientes
            # antes de crear el nuevo bridge, para no dejar un MCP apuntando al
            # workspace anterior.
            for worker in list(self._mcp_workers.values()):
                worker.client.close()
            for server_id in list(self.mcp.active_servers):
                self.mcp.deactivate(server_id)
            self.workspace = Workspace(selected)
            self.tools = ToolRegistry(self.workspace)
            self.mcp = MCPToolBridge(self.tools)
            self._refresh_mcp_buttons()
            self.config.workspace = str(Path(selected).resolve())
            self.config.save()
            self.workspace_label.setText(self._workspace_display_name())
            self.status.setText("Workspace cambiado")
        except WorkspaceError as exc:
            QMessageBox.warning(self, "Workspace", str(exc))

    def _toggle_mcp(self) -> None:
        if self._streaming:
            return

        result = self._mcp_command_dialog()
        if result is None:
            return
        server_id, command = result
        if server_id in self.mcp.active_servers or server_id in self._mcp_threads:
            QMessageBox.warning(self, "MCP", f"Ya existe un servidor llamado «{server_id}».")
            return

        try:
            parts = shlex.split(command)
            if not parts:
                raise ValueError("El comando MCP está vacío.")
            client = MCPClient(
                MCPServerConfig(
                    command=parts[0],
                    args=tuple(parts[1:]),
                    cwd=str(self.workspace.root),
                )
            )
            self.status.setText(f"Consultando herramientas MCP de «{server_id}»…")
            self.mcp_add_button.setEnabled(False)

            thread = QThread()
            worker = MCPWorker(client)
            self._mcp_threads[server_id] = thread
            self._mcp_workers[server_id] = worker
            worker.moveToThread(thread)
            thread.started.connect(worker.run)
            # IMPORTANTE: no usar lambdas aquí. Una conexión de señal a un
            # callable sin QObject receptor puede ejecutarse en el hilo emisor.
            # En macOS eso provoca un crash si el callback toca QWidget/QMessageBox.
            # El worker solo emite datos; los slots de MainWindow reciben siempre
            # la actualización en el hilo de la UI.
            worker.finished.connect(self._mcp_loaded)
            worker.error.connect(self._mcp_error)
            worker.finished.connect(thread.quit)
            worker.error.connect(thread.quit)
            thread.finished.connect(self._cleanup_finished_mcp_threads)
            thread.start()
        except (MCPError, ValueError) as exc:
            QMessageBox.warning(self, "MCP", str(exc))
        finally:
            self._refresh_mcp_buttons()

    @Slot(object, list)
    def _mcp_loaded(
        self,
        client: MCPClient,
        tools: list[dict[str, Any]],
    ) -> None:
        server_id = next(
            (sid for sid, pending in self._mcp_workers.items() if pending.client is client),
            None,
        )
        if server_id is None:
            return
        try:
            self.mcp.activate(server_id, client, tools)
            count = sum(
                1
                for item in self.mcp.definitions()
                if item.get("function", {}).get("name", "").startswith(
                    f"mcp__{server_id}__"
                )
            )
            self.status.setText(f"MCP «{server_id}» activo · {count} herramienta(s)")
        except Exception as exc:
            self.mcp.deactivate(server_id)
            self.status.setText(f"MCP «{server_id}» no disponible")
            QMessageBox.warning(self, "MCP", f"«{server_id}»: {exc}")
        self._refresh_mcp_buttons()

    @Slot(str)
    def _mcp_error(self, message: str) -> None:
        # El server_id se recupera por el worker que emitió la señal.
        sender = self.sender()
        server_id = next(
            (sid for sid, worker in self._mcp_workers.items() if worker is sender),
            None,
        )
        if server_id is None:
            return
        self.mcp.deactivate(server_id)
        self.status.setText(f"MCP «{server_id}» no disponible")
        QMessageBox.warning(self, "MCP", f"«{server_id}»: {message}")
        self._refresh_mcp_buttons()

    @Slot()
    def _cleanup_finished_mcp_threads(self) -> None:
        finished_ids = [
            sid for sid, thread in self._mcp_threads.items() if not thread.isRunning()
        ]
        for server_id in finished_ids:
            worker = self._mcp_workers.pop(server_id, None)
            thread = self._mcp_threads.pop(server_id, None)
            if worker is not None:
                worker.deleteLater()
            if thread is not None:
                thread.deleteLater()
        self.mcp_add_button.setEnabled(not self._streaming)
        self._refresh_mcp_buttons()

    def _deactivate_mcp_server(self, server_id: str) -> None:
        if self._streaming or server_id in self._mcp_threads:
            return
        self.mcp.deactivate(server_id)
        self.status.setText(f"MCP «{server_id}» desactivado")
        self._refresh_mcp_buttons()

    def _refresh_mcp_buttons(self) -> None:
        while self.mcp_servers_layout.count():
            item = self.mcp_servers_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        for server_id in self.mcp.active_servers:
            row = QWidget()
            layout = QHBoxLayout(row)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(4)
            label = QLabel(server_id)
            label.setObjectName("FolderLabel")
            button = QPushButton("Desactivar")
            button.setObjectName("SecondaryButton")
            button.setEnabled(not self._streaming)
            button.clicked.connect(
                lambda checked=False, sid=server_id: self._deactivate_mcp_server(sid)
            )
            layout.addWidget(label, 1)
            layout.addWidget(button)
            self.mcp_servers_layout.addWidget(row)

        for server_id in self._mcp_threads:
            if server_id in self.mcp.active_servers:
                continue
            row = QWidget()
            layout = QHBoxLayout(row)
            layout.setContentsMargins(0, 0, 0, 0)
            label = QLabel(f"{server_id} (conectando…)")
            label.setObjectName("FolderLabel")
            layout.addWidget(label)
            self.mcp_servers_layout.addWidget(row)

        self.mcp_add_button.setEnabled(not self._streaming)

    def _mcp_command_dialog(self) -> tuple[str, str] | None:
        from PySide6.QtWidgets import QDialog, QDialogButtonBox, QFormLayout, QLineEdit

        dialog = QDialog(self)
        dialog.setWindowTitle("Añadir servidor MCP")
        layout = QFormLayout(dialog)

        server_id = QLineEdit()
        server_id.setPlaceholderText("ej. fs, github, demo")
        server_id.setText("fs")
        layout.addRow("Nombre:", server_id)

        filesystem_command = (
            "npx -y @modelcontextprotocol/server-filesystem "
            f"{shlex.quote(str(self.workspace.root))}"
        )
        command = QLineEdit(filesystem_command)
        layout.addRow("Comando stdio:", command)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None
        name = server_id.text().strip()
        cmd = command.text().strip()
        if not name:
            QMessageBox.warning(self, "MCP", "El nombre del servidor no puede estar vacío.")
            return None
        if not cmd:
            QMessageBox.warning(self, "MCP", "El comando MCP no puede estar vacío.")
            return None
        return name, cmd

    def _send(self) -> None:
        if self._streaming:
            if self._worker is not None:
                self._worker.cancel()
            return
        text = self.input.toPlainText().strip()
        model = self.model_combo.currentText().strip()
        if not text or not model:
            return

        self.input.clear()
        self._insert_user_message(text)
        self.messages.append({"role": "user", "content": text})
        self.chat_render.reset()
        self._streaming = True
        self.send.setEnabled(True)
        self.send.setText("Detener")
        self.input.setEnabled(False)
        self.status.setText("Generando…")
        self._start_indicators()
        self.config.model = model
        self.config.save()

        self._thread = QThread()
        self._worker = ChatWorker(self.ollama, model, list(self.messages), self.mcp)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.text.connect(self._on_text)
        self._worker.tool.connect(self._on_tool)
        self._worker.tool_result.connect(self._on_tool_result)
        self._worker.confirmation_requested.connect(self._confirm_destructive)
        self._worker.finished.connect(self._done)
        self._worker.error.connect(self._error)
        self._worker.cancelled.connect(self._cancelled)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._worker.cancelled.connect(self._thread.quit)
        self._thread.finished.connect(self._cleanup_thread)
        self._thread.start()

    def _insert_user_message(self, text: str) -> None:
        self.chat_render.insert_user_message(text)

    @staticmethod
    def _display_response_text(text: str) -> str:
        """Normaliza saltos reales y escapados sin perder párrafos."""
        return ChatRenderer.display_response_text(text)

    @staticmethod
    def _clean_response_text(text: str) -> str:
        """Elimina un encabezado PEREZOSO que algunos modelos añaden a la respuesta."""
        return ChatRenderer.clean_response_text(text)

    def _on_text(self, text: str) -> None:
        self.chat_render.on_text(text)

    @property
    def _response_start(self) -> int | None:
        return self.chat_render.response_start

    def _reset_response_segment(self) -> None:
        self.chat_render.reset_response_segment()

    def _confirm_destructive(self, name: str, arguments: dict[str, Any]) -> None:
        if self._worker is None:
            return
        if name == "borrar_archivo":
            path = str(arguments.get("path", ""))
            text = f"¿Quieres borrar el archivo «{path}»?\n\nEsta operación no se puede deshacer."
            title = "Confirmar borrado"
        elif name == "crear_carpeta":
            path = str(arguments.get("path", ""))
            text = f"¿Quieres crear la carpeta «{path}»?"
            title = "Confirmar creación de carpeta"
        elif name in {"crear_archivo", "escribir_archivo"}:
            path = str(arguments.get("path", ""))
            content = str(arguments.get("content", ""))
            preview = content if len(content) <= 800 else content[:800] + "\n…(contenido truncado)"
            action = "crear" if name == "crear_archivo" else "escribir o reemplazar"
            text = (
                f"¿Quieres {action} el archivo «{path}» con este contenido?\n\n"
                f"{preview if preview else '(vacío)'}\n\n"
                "Esta operación solo se realizará si la confirmas."
            )
            title = "Confirmar escritura"
        else:
            detail = str(arguments)
            text = (
                f"La herramienta MCP «{name}» puede modificar o ejecutar acciones.\n\n"
                f"Argumentos: {detail}\n\n¿Quieres permitir esta operación?"
            )
            title = "Confirmar operación MCP"
        reply = QMessageBox.question(
            self, title, text,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        self._worker.resolve_confirmation(reply == QMessageBox.StandardButton.Yes)

    def _on_tool(self, name: str) -> None:
        self._insert_tool_event(f"Herramienta: {name}", design.TOOL_EVENT_COLOR)

    def _on_tool_result(self, name: str, result: str) -> None:
        if result.startswith("ERROR:"):
            label = f"Error en {name}"
            color = design.TOOL_EVENT_ERROR_COLOR
        elif result.startswith("OPERACIÓN CANCELADA"):
            label = "Operación cancelada"
            color = design.TOOL_EVENT_CANCELLED_COLOR
        else:
            label = f"Resultado: {name}"
            color = design.TOOL_EVENT_COLOR
        self._insert_tool_event(label, color)
        preview = result.strip()
        if len(preview) > 1200:
            preview = preview[:1200] + "\n…"
        if preview:
            self._insert_tool_result(preview)

    def _insert_tool_event(self, text: str, color: str) -> None:
        self.chat_render.insert_tool_event(text, color)

    def _insert_tool_result(self, text: str) -> None:
        self.chat_render.insert_tool_result(text)

    def _done(self, result: str) -> None:
        response_text = self.chat_render.response_text or result
        response_text = self._clean_response_text(self._display_response_text(response_text))
        self.messages.append({"role": "assistant", "content": response_text})
        self._finish_response("Listo")

    def _cancelled(self) -> None:
        self._finish_response("Cancelado")

    def _error(self, message: str) -> None:
        self.chat_render.insert_error(message)
        self._finish_response("Error")

    def _finish_response(self, status: str) -> None:
        self._stop_indicators()
        self._streaming = False
        self.send.setEnabled(True)
        self.send.setText("Enviar")
        self.input.setEnabled(True)
        self.status.setText(status)
        self.chat.append("")

    def _start_indicators(self) -> None:
        self._thinking_step = 0
        self.thinking_label.setText("•••")
        self.thinking_label.show()
        self._elapsed.start()
        self.elapsed_label.show()
        self._thinking_timer.start()
        self._elapsed_timer.start()

    def _stop_indicators(self) -> None:
        self._thinking_timer.stop()
        self._elapsed_timer.stop()
        self.thinking_label.hide()
        seconds = self._elapsed.elapsed() / 1000 if self._elapsed.isValid() else 0.0
        self.elapsed_label.setText(f"● {seconds:.1f} s")

    def _animate_thinking(self) -> None:
        states = ("•", "••", "•••")
        self._thinking_step = (self._thinking_step + 1) % len(states)
        self.thinking_label.setText(states[self._thinking_step])

    def _update_elapsed(self) -> None:
        self.elapsed_label.setText(f"● {self._elapsed.elapsed() / 1000:.1f} s")

    def _clear_chat(self) -> None:
        if self._streaming:
            return
        self.messages.clear()
        self.chat.clear()
        self.status.setText("Nueva conversación")

    def _cleanup_thread(self) -> None:
        if self._thread is not None:
            self._thread.deleteLater()
        self._thread = None
        self._worker = None

    def closeEvent(self, event) -> None:
        self.config.width = self.width()
        self.config.height = self.height()
        self.config.save()
        if self._worker is not None:
            self._worker.cancel()
        self.mcp.deactivate()
        for worker in list(self._mcp_workers.values()):
            worker.client.close()
        for thread in (self._thread, self._model_thread, *self._mcp_threads.values()):
            if thread is not None and thread.isRunning():
                thread.quit()
                thread.wait(2000)
        event.accept()
