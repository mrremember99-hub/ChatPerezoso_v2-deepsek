"""Valores de diseño de la interfaz: colores, tipografías y espaciados que
no vive en theme.py (DARK_STYLE) porque se aplican a mano — en paintEvent,
en HTML inyectado en el chat, o en construcción de widgets — en vez de por
QSS. Cambiar el aspecto de la burbuja, los márgenes de respuesta o los
colores de los eventos de herramienta se hace aquí, en un solo sitio.
"""
from __future__ import annotations

# -- burbuja de usuario (ChatView.paintEvent) --------------------------------

BUBBLE_FILL_COLOR = "#1B2422"
BUBBLE_BORDER_COLOR = "#59645F"
BUBBLE_BORDER_WIDTH = 1
BUBBLE_CORNER_RADIUS = 18

# -- mensaje de usuario (HTML insertado en el chat) --------------------------

USER_MESSAGE_TEXT_COLOR = "#E9F0EC"
USER_MESSAGE_FONT_SIZE_PX = 14
# margin: top right bottom left — el 50% de la izquierda es lo que empuja
# la burbuja a la mitad derecha del chat.
USER_MESSAGE_MARGIN = "2px 5px 2px 50%"
USER_MESSAGE_PADDING = "16px 18px"

# -- respuesta en streaming (párrafo a párrafo) ------------------------------

RESPONSE_RIGHT_MARGIN_RATIO = 0.25  # ancho útil de la respuesta = 75%
RESPONSE_FIRST_PARAGRAPH_TOP_MARGIN = 20.0
RESPONSE_PARAGRAPH_TOP_MARGIN = 2.0
RESPONSE_PARAGRAPH_BOTTOM_MARGIN = 4.0

# -- eventos de herramienta (línea "Herramienta: X" / "Resultado: X") -------

TOOL_EVENT_COLOR = "#8A9690"
TOOL_EVENT_ERROR_COLOR = "#D98C8C"
TOOL_EVENT_CANCELLED_COLOR = "#D8B77A"
TOOL_EVENT_FONT_SIZE_PT = 8

# -- caja de resultado de herramienta -----------------------------------------

TOOL_RESULT_BG_COLOR = "#171D1B"
TOOL_RESULT_BORDER_COLOR = "#303936"
TOOL_RESULT_TEXT_COLOR = "#B9C4BF"
TOOL_RESULT_BORDER_RADIUS_PX = 6
TOOL_RESULT_FONT_SIZE_PT = 9

# -- layout de la ventana principal ------------------------------------------

SIDEBAR_WIDTH_PX = 240
CHAT_INPUT_HEIGHT_PX = 72

# -- indicadores (animación "pensando" / cronómetro) -------------------------

THINKING_TIMER_INTERVAL_MS = 420
ELAPSED_TIMER_INTERVAL_MS = 100
