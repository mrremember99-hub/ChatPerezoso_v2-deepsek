"""Widgets pequeños y autocontenidos del chat: sin lógica de red ni de estado
de la aplicación, solo comportamiento visual/de interacción de un control.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QKeyEvent, QPainter, QPen
from PySide6.QtWidgets import QPlainTextEdit, QTextEdit

from . import design

# Marca en el QTextBlockFormat que identifica los bloques de burbuja de
# usuario, para que ChatView sepa a cuáles dibujar el fondo redondeado.
USER_MESSAGE_PROPERTY = 1001


class ChatView(QTextEdit):
    """Vista del chat que dibuja las burbujas de usuario con esquinas redondeadas."""

    def paintEvent(self, event) -> None:
        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        layout = self.document().documentLayout()
        block = self.document().begin()
        while block.isValid():
            if block.blockFormat().property(USER_MESSAGE_PROPERTY):
                rect = layout.blockBoundingRect(block)
                rect.translate(
                    -self.horizontalScrollBar().value(),
                    -self.verticalScrollBar().value(),
                )
                rect.adjust(0, 1, -5, -1)
                painter.setBrush(QColor(design.BUBBLE_FILL_COLOR))
                painter.setPen(QPen(QColor(design.BUBBLE_BORDER_COLOR), design.BUBBLE_BORDER_WIDTH))
                painter.drawRoundedRect(
                    rect, design.BUBBLE_CORNER_RADIUS, design.BUBBLE_CORNER_RADIUS
                )
            block = block.next()
        painter.end()
        super().paintEvent(event)


class ChatInput(QPlainTextEdit):
    submitted = Signal()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not (
            event.modifiers() & Qt.ShiftModifier
        ):
            self.submitted.emit()
            return
        super().keyPressEvent(event)
