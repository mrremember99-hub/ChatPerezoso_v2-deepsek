DARK_STYLE = """
QMainWindow, QDialog, QWidget {
    background-color: #101315;
    color: #E9F0EC;
    font-family: 'Avenir Next', 'Segoe UI', sans-serif;
}
QSplitter::handle { background-color: #1C2422; width: 1px; }
QScrollBar:vertical { border: none; background: #111718; width: 9px; margin: 2px 0; }
QScrollBar::handle:vertical { background: #34413D; min-height: 28px; border-radius: 4px; }
QScrollBar::handle:vertical:hover { background: #60786D; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { height: 0px; background: transparent; }
QTextEdit, QPlainTextEdit {
    background-color: #151B1C;
    border: 1px solid #293432;
    border-radius: 10px;
    color: #E9F0EC;
    padding: 12px;
    selection-background-color: #B8E8C8;
    selection-color: #101315;
}
QTextEdit#ChatView {
    background-color: #121819;
    border: none;
    padding: 18px 22px;
    font-size: 14px;
}
QPlainTextEdit#ChatInput {
    background-color: #171F20;
    border: 1px solid #34423E;
    border-radius: 12px;
    padding: 12px 14px;
    font-size: 14px;
}
QTextEdit:focus, QPlainTextEdit:focus, QLineEdit:focus, QComboBox:focus { border: 1px solid #8FD6A9; }
QComboBox {
    background-color: #151D1E;
    border: 1px solid #2D3A37;
    border-radius: 7px;
    color: #E9F0EC;
    padding: 8px 10px;
    min-height: 18px;
}
QComboBox::drop-down { border: none; width: 26px; }
QComboBox QAbstractItemView { background-color: #1A2423; color: #E9F0EC; selection-background-color: #315344; selection-color: #F5FFF7; border: 1px solid #3C5048; }
QPushButton {
    background-color: #B8E8C8;
    color: #102118;
    font-weight: 600;
    border: 1px solid #B8E8C8;
    border-radius: 7px;
    padding: 5px 8px;
    min-height: 10px;
    font-size: 11px;
}
QPushButton:hover { background-color: #D2F2DC; border-color: #D2F2DC; }
QPushButton:pressed { background-color: #8FCBA2; border-color: #8FCBA2; }
QPushButton:disabled, QComboBox:disabled { background-color: #1B2323; color: #66736D; border-color: #27312F; }
QWidget#Sidebar { background-color: #151C1D; border-right: 1px solid #263230; }
QLabel#AppTitle { color: #F2F7F3; font-size: 21px; font-weight: 700; padding: 2px 0 6px; background-color: transparent; }
QLabel#SectionTitle { color: #8FA79A; font-size: 10px; font-weight: 700; padding-top: 5px; background-color: transparent; }
QLabel#FolderLabel { color: #A9B9B0; background: transparent; background-color: rgba(0, 0, 0, 0); border: none; padding: 4px 0 8px; }
QLabel#FolderLabel:focus { background: transparent; background-color: rgba(0, 0, 0, 0); }
QPushButton#SecondaryButton {
    background-color: #182220;
    color: #C7D6CF;
    border: 1px solid #2D3A37;
    border-radius: 8px;
    padding: 8px 10px;
    text-align: left;
    font-weight: 600;
    font-size: 11px;
    min-height: 14px;
}
QPushButton#SecondaryButton:hover { background-color: #20302B; border-color: #3C5048; color: #E9F0EC; }
QPushButton#SecondaryButton:pressed { background-color: #131C1A; }
QPushButton#SecondaryButton:disabled { background-color: #141B1A; color: #5E6B65; border-color: #232D2B; }
QStatusBar { background-color: #151C1D; color: #8FA79A; border-top: 1px solid #263230; }
QLabel#StatusText { color: #8FA79A; }
QLabel#ElapsedIndicator { color: #8FD6A9; font-size: 11px; padding: 0 8px; }
QLabel#ThinkingLabel { color: #8FD6A9; font-size: 15px; font-weight: 600; padding: 0 4px 2px; }
QWidget#ChatArea { background-color: #101516; }
"""
